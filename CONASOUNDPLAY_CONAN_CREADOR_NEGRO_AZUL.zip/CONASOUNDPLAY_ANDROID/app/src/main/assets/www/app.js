/* CONASOUNDPLAY frontend. API_BASE queda vacío hasta desplegar Cloudflare Worker. */
const API_BASE = ""; // Ejemplo futuro: "https://tu-worker.tu-cuenta.workers.dev"
const demoTracks = [
  {id:"demo-1",title:"RKT de la Noche",artist:"CONASOUNDPLAY Demo · RKT",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",duration:"—",genre:"RKT"},
  {id:"demo-2",title:"Funk de Rua",artist:"CONASOUNDPLAY Demo · Funk",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",duration:"—",genre:"Funk"},
  {id:"demo-3",title:"Cumbia de Medianoche",artist:"CONASOUNDPLAY Demo · Cumbia",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",duration:"—",genre:"Cumbia"},
  {id:"demo-4",title:"Pop para el Viaje",artist:"CONASOUNDPLAY Demo · Pop",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",duration:"—",genre:"Pop"},
  {id:"demo-5",title:"Modo Chill",artist:"CONASOUNDPLAY Demo · Chill",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",duration:"—",genre:"Chill"},
  {id:"demo-6",title:"Rock de Ruta",artist:"CONASOUNDPLAY Demo · Rock",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",duration:"—",genre:"Rock"},
  {id:"demo-7",title:"Electro Neon",artist:"CONASOUNDPLAY Demo · Electrónica",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",duration:"—",genre:"Electrónica"},
  {id:"demo-8",title:"Reggaetón Suave",artist:"CONASOUNDPLAY Demo · Reggaetón",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",duration:"—",genre:"Reggaetón"},
  {id:"demo-9",title:"Trap de Madrugada",artist:"CONASOUNDPLAY Demo · Trap",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",duration:"—",genre:"Trap"},
  {id:"demo-10",title:"Balada para Pensar",artist:"CONASOUNDPLAY Demo · Balada",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",duration:"—",genre:"Balada"},
  {id:"demo-11",title:"Cumbia para Bailar",artist:"CONASOUNDPLAY Demo · Cumbia",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3",duration:"—",genre:"Cumbia"},
  {id:"demo-12",title:"Lo-Fi de Estudio",artist:"CONASOUNDPLAY Demo · Lo-fi",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3",duration:"—",genre:"Lo-fi"},
  {id:"demo-13",title:"Latino Mix",artist:"CONASOUNDPLAY Demo · Latino",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3",duration:"—",genre:"Latino"},
  {id:"demo-14",title:"Dance sin Parar",artist:"CONASOUNDPLAY Demo · Dance",url:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3",duration:"—",genre:"Dance"}
];
let tracks=[...demoTracks], currentIndex=0, isRegister=false, sessionUser=null, onlineSearchTimer=null, onlineSearchSequence=0;
const $=id=>document.getElementById(id);
const audio=$("audio");
const formatTime=s=>Number.isFinite(s)?`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`:"0:00";

// Descargas: archivo del teléfono y copia offline administrada por la app.
const DB_NAME="conasoundplay_downloads_v1", DB_STORE="tracks";
function openDownloadsDB(){return new Promise((resolve,reject)=>{if(!("indexedDB" in window)){reject(new Error("Este navegador no admite almacenamiento offline."));return}const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(DB_STORE))req.result.createObjectStore(DB_STORE,{keyPath:"id"})};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error("No se pudo abrir el almacenamiento."))})}
async function storeOfflineTrack(track,blob){const db=await openDownloadsDB();return new Promise((resolve,reject)=>{const tx=db.transaction(DB_STORE,"readwrite");tx.objectStore(DB_STORE).put({id:track.id,title:track.title,artist:track.artist,blob,savedAt:Date.now()});tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error||new Error("No se pudo guardar la canción."))}})}
async function getOfflineTrack(id){try{const db=await openDownloadsDB();return await new Promise(resolve=>{const req=db.transaction(DB_STORE,"readonly").objectStore(DB_STORE).get(id);req.onsuccess=()=>{db.close();resolve(req.result?.blob||null)};req.onerror=()=>{db.close();resolve(null)}})}catch{return null}}
async function downloadAudioBlob(track){const response=await fetch(track.url);if(!response.ok)throw new Error("No se pudo descargar el audio.");return await response.blob()}
async function downloadToPhone(track){try{const blob=await downloadAudioBlob(track);const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=(track.title||"cancion").replace(/[^a-z0-9áéíóúñ _-]/gi,"").trim()+".mp3";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);alert("Descarga iniciada. Revisá la carpeta Descargas del celular.")}catch(e){alert("No se pudo descargar como archivo. Puede que la fuente de audio bloquee la descarga; probá con otra pista o una fuente autorizada.")}}
async function saveInsideApp(track,button){const original=button.textContent;button.disabled=true;button.textContent="Guardando…";try{const blob=await downloadAudioBlob(track);await storeOfflineTrack(track,blob);button.textContent="✓ Guardada";alert(`“${track.title}” quedó guardada en CONASOUNDPLAY para escucharla sin conexión en este navegador.`)}catch(e){alert("No se pudo guardar offline. La fuente puede bloquear la descarga o el navegador no tener espacio disponible.");button.textContent=original}finally{button.disabled=false}}
function renderTracks(filter=""){
  const list=$("trackList"); list.innerHTML="";
  const shown=tracks.filter(t=>(t.title+" "+t.artist+" "+(t.genre||"")).toLowerCase().includes(filter.toLowerCase()));
  $("trackCount").textContent=`${shown.length} pista${shown.length===1?"":"s"}`;
  shown.forEach(t=>{
    const i=tracks.findIndex(x=>x.id===t.id), card=document.createElement("article");
    card.className="track-card"+(i===currentIndex?" active":"");
    const art=document.createElement("div"); art.className="track-art art-"+((i%8)+1);
    const glyph=document.createElement("span"); glyph.textContent=["♫","✦","♪","◉","☾","♬","✧","♩"][i%8]; art.append(glyph);
    const play=document.createElement("button"); play.className="card-play";play.textContent=i===currentIndex&&!audio.paused?"Ⅱ":"▶";play.setAttribute("aria-label","Reproducir "+t.title);play.onclick=()=>playTrack(i);
    art.append(play);
    const info=document.createElement("div"); info.className="track-card-info";
    const name=document.createElement("strong"), artist=document.createElement("small"), genre=document.createElement("span");
    name.textContent=t.title;artist.textContent=t.artist;genre.className="track-genre";genre.textContent=t.genre||"Mix";
    info.append(name,artist,genre);
    const fav=document.createElement("button");fav.className="card-fav icon-btn";fav.textContent=isFavorite(t.id)?"♥":"♡";fav.classList.toggle("liked",isFavorite(t.id));fav.title="Favorito";fav.onclick=()=>toggleFavorite(t.id);
    const downloads=document.createElement("div");downloads.className="track-download-actions";
    const phoneBtn=document.createElement("button");phoneBtn.className="download-action";phoneBtn.textContent="↓ Celular";phoneBtn.title="Descargar como archivo al teléfono";phoneBtn.onclick=()=>downloadToPhone(t);
    const appBtn=document.createElement("button");appBtn.className="download-action";appBtn.textContent="＋ En la app";appBtn.title="Guardar dentro de CONASOUNDPLAY para escuchar sin conexión";appBtn.onclick=()=>saveInsideApp(t,appBtn);
    downloads.append(phoneBtn,appBtn);card.append(art,info,fav,downloads);list.append(card);
  });
}
function getFavorites(){try{return JSON.parse(localStorage.getItem("cona_favorites")||"[]")}catch{return []}}
function isFavorite(id){return getFavorites().includes(id)}
function toggleFavorite(id){let f=getFavorites();f=f.includes(id)?f.filter(x=>x!==id):[...f,id];localStorage.setItem("cona_favorites",JSON.stringify(f));renderTracks($("searchInput").value);$("favoriteCurrent").textContent=isFavorite(tracks[currentIndex]?.id)?"♥":"♡";$("favoriteCurrent").classList.toggle("liked",isFavorite(tracks[currentIndex]?.id))}
async function playTrack(i){currentIndex=(i+tracks.length)%tracks.length;const saved=await getOfflineTrack(tracks[currentIndex].id);if(audio.dataset.objectUrl){URL.revokeObjectURL(audio.dataset.objectUrl);delete audio.dataset.objectUrl}if(saved){const objectUrl=URL.createObjectURL(saved);audio.dataset.objectUrl=objectUrl;audio.src=objectUrl}else{audio.src=tracks[currentIndex].url;}$("nowTitle").textContent=tracks[currentIndex].title;$("nowSubtitle").textContent=tracks[currentIndex].artist;$("favoriteCurrent").textContent=isFavorite(tracks[currentIndex].id)?"♥":"♡";$("favoriteCurrent").classList.toggle("liked",isFavorite(tracks[currentIndex].id));audio.play().then(()=>{$("playBtn").textContent="Ⅱ"}).catch(()=>{$("playBtn").textContent="▶";alert("No se pudo reproducir la pista. Revisá tu conexión o elegí otra.")});renderTracks($("searchInput").value)}
function togglePlayback(){if(!audio.src){playTrack(0);return}if(audio.paused){audio.play().then(()=>$("playBtn").textContent="Ⅱ").catch(()=>{});}else{audio.pause();$("playBtn").textContent="▶"}}
$("playBtn").onclick=togglePlayback;$("heroPlay").onclick=()=>playTrack(currentIndex);$("nextBtn").onclick=()=>playTrack(currentIndex+1);$("prevBtn").onclick=()=>playTrack(currentIndex-1);
$("favoriteCurrent").onclick=()=>tracks[currentIndex]&&toggleFavorite(tracks[currentIndex].id);
audio.addEventListener("play",()=>{$("playBtn").textContent="Ⅱ";renderTracks($("searchInput").value)});
audio.addEventListener("pause",()=>{$("playBtn").textContent="▶";renderTracks($("searchInput").value)});
audio.addEventListener("timeupdate",()=>{if(audio.duration){$("seek").value=audio.currentTime/audio.duration*100;$("currentTime").textContent=formatTime(audio.currentTime);$("duration").textContent=formatTime(audio.duration)}});
audio.addEventListener("ended",()=>playTrack(currentIndex+1));
$("seek").oninput=e=>{if(audio.duration)audio.currentTime=audio.duration*Number(e.target.value)/100};
$("searchInput").addEventListener("input",e=>{const q=e.target.value.trim();renderTracks(q);clearTimeout(onlineSearchTimer);if(q.length<2){$("onlineSearchResults").innerHTML="";$("onlineSearchStatus").textContent="Buscá una canción para encontrar más música en Internet.";return}$("onlineSearchStatus").textContent="Buscando canciones en Internet…";onlineSearchTimer=setTimeout(()=>searchOnlineMusic(q),450);});

// Buscador multi-fuente: Apple/iTunes para previews oficiales, Internet Archive para audio descargable,
// y enlaces de búsqueda en YouTube, SoundCloud y Spotify. Cada proveedor conserva sus propias reglas.
async function searchOnlineMusic(query){
  const seq=++onlineSearchSequence, box=$("onlineSearchResults"), status=$("onlineSearchStatus");
  box.innerHTML="";
  const q=String(query||"").trim(); if(q.length<2)return;
  const sources=[
    {name:"YouTube",url:"https://www.youtube.com/results?search_query="+encodeURIComponent(q)},
    {name:"SoundCloud",url:"https://soundcloud.com/search/sounds?q="+encodeURIComponent(q)},
    {name:"Spotify",url:"https://open.spotify.com/search/"+encodeURIComponent(q)}
  ];
  const linkbar=document.createElement("div");linkbar.className="online-actions source-links";
  sources.forEach(src=>{const b=document.createElement("button");b.className="online-action";b.textContent="Buscar en "+src.name;b.onclick=()=>openExternal(src.url);linkbar.append(b)});
  box.append(linkbar);
  status.textContent="Buscando en Apple Music/iTunes e Internet Archive… También podés abrir YouTube, SoundCloud o Spotify.";
  const tasks=[searchAppleCatalog(q),searchInternetArchive(q)];
  const settled=await Promise.allSettled(tasks); if(seq!==onlineSearchSequence)return;
  let count=0;
  for(const result of settled){if(result.status==="fulfilled")count+=result.value.length;}
  if(seq!==onlineSearchSequence)return;
  if(!count){status.textContent="No aparecieron resultados reproducibles en los catálogos abiertos. Probá otro título o usá los botones de YouTube, SoundCloud y Spotify.";return}
  status.textContent=`Encontramos ${count} resultados en catálogos abiertos. Las vistas previas y descargas dependen de cada fuente.`;
}
async function searchAppleCatalog(query){
  const params=new URLSearchParams({term:query,country:"AR",media:"music",entity:"song",limit:"18"});
  const response=await fetch("https://itunes.apple.com/search?"+params.toString());if(!response.ok)throw new Error("Apple catalog unavailable");
  const data=await response.json(), results=(data.results||[]).filter(x=>x.trackName&&x.artistName);
  results.forEach(track=>{
    const playable=track.previewUrl||"";
    const card=document.createElement("article");card.className="online-track";
    const img=document.createElement("img");img.className="online-cover";img.alt="Portada de "+track.trackName;img.loading="lazy";img.src=(track.artworkUrl100||"").replace("100x100bb","200x200bb");
    const info=document.createElement("div");info.className="online-track-info";
    const title=document.createElement("strong");title.textContent=track.trackName;
    const artist=document.createElement("small");artist.textContent=track.artistName+(track.collectionName?" · "+track.collectionName:"")+" · Apple/iTunes";info.append(title,artist);
    const actions=document.createElement("div");actions.className="online-actions";
    if(playable){const play=document.createElement("button");play.className="online-action primary-online";play.textContent="▶ Vista previa";play.onclick=()=>playOnlineTrack({id:"apple-"+track.trackId,title:track.trackName,artist:track.artistName,url:playable,genre:"Apple/iTunes"});actions.append(play);
      const save=document.createElement("button");save.className="online-action";save.textContent="↓ Guardar preview";save.onclick=()=>saveOnlinePreview({id:"apple-"+track.trackId,title:track.trackName,artist:track.artistName,url:playable},save);actions.append(save);
    } else {const no=document.createElement("small");no.textContent="Sin vista previa disponible";actions.append(no)}
    if(track.trackViewUrl){const apple=document.createElement("button");apple.className="online-action";apple.textContent="Abrir Apple";apple.onclick=()=>openExternal(track.trackViewUrl);actions.append(apple)}
    const yt=document.createElement("button");yt.className="online-action";yt.textContent="YouTube";yt.onclick=()=>openExternal("https://www.youtube.com/results?search_query="+encodeURIComponent(track.trackName+" "+track.artistName));actions.append(yt);
    card.append(img,info,actions);$("onlineSearchResults").append(card);
  });return results.length;
}
async function searchInternetArchive(query){
  // Internet Archive ofrece grabaciones y archivos compartidos por sus titulares; solo mostramos formatos de audio.
  const url="https://archive.org/advancedsearch.php?"+new URLSearchParams({q:'mediatype:audio AND (title:"'+query.replace(/["\\]/g," ")+'" OR creator:"'+query.replace(/["\\]/g," ")+'")',"fl[]":"identifier,title,creator",rows:"8",page:"1",output:"json"}).toString();
  const response=await fetch(url);if(!response.ok)throw new Error("Internet Archive unavailable");const data=await response.json();
  const docs=(data.response&&data.response.docs)||[];
  const items=await Promise.all(docs.slice(0,8).map(async doc=>{try{const r=await fetch("https://archive.org/metadata/"+encodeURIComponent(doc.identifier));if(!r.ok)return null;const m=await r.json();const files=(m.files||[]).filter(f=>/\.(mp3|ogg|oga|flac|wav|m4a)$/i.test(f.name||"")&&!f.name.includes("__ia_thumb"));const f=files.find(x=>/mp3/i.test(x.name))||files.find(x=>/ogg|oga/i.test(x.name))||files[0];if(!f)return null;return {doc,file:f}}catch{return null}}));
  items.filter(Boolean).forEach(({doc,file})=>{
    const audioUrl="https://archive.org/download/"+encodeURIComponent(doc.identifier)+"/"+file.name.split("/").map(encodeURIComponent).join("/");
    const title=doc.title||file.name,artist=doc.creator||"Internet Archive";
    const card=document.createElement("article");card.className="online-track";
    const art=document.createElement("div");art.className="online-cover archive-cover";art.textContent="♫";
    const info=document.createElement("div");info.className="online-track-info";const name=document.createElement("strong");name.textContent=title;const by=document.createElement("small");by.textContent=artist+" · Internet Archive";info.append(name,by);
    const actions=document.createElement("div");actions.className="online-actions";
    const play=document.createElement("button");play.className="online-action primary-online";play.textContent="▶ Reproducir";play.onclick=()=>playOnlineTrack({id:"ia-"+doc.identifier+"-"+file.name,title,artist,url:audioUrl,genre:"Internet Archive"});
    const save=document.createElement("button");save.className="online-action";save.textContent="↓ Guardar en app";save.onclick=()=>saveOnlinePreview({id:"ia-"+doc.identifier+"-"+file.name,title,artist,url:audioUrl},save);
    const open=document.createElement("button");open.className="online-action";open.textContent="Ver fuente/licencia";open.onclick=()=>openExternal("https://archive.org/details/"+encodeURIComponent(doc.identifier));actions.append(play,save,open);
    card.append(art,info,actions);$("onlineSearchResults").append(card);
  });return items.filter(Boolean).length;
}
function playOnlineTrack(track){
  if(audio.dataset.objectUrl){URL.revokeObjectURL(audio.dataset.objectUrl);delete audio.dataset.objectUrl}
  currentIndex=-1;audio.src=track.url;$("nowTitle").textContent=track.title;$("nowSubtitle").textContent=track.artist;$("playBtn").textContent="▶";
  audio.play().then(()=>{$("playBtn").textContent="Ⅱ"}).catch(()=>alert("Esta fuente no permitió reproducir el audio directamente. Abrí la fuente original o probá otra pista."));
}
async function saveOnlinePreview(track,button){const old=button.textContent;button.disabled=true;button.textContent="Guardando…";try{const blob=await downloadAudioBlob(track);await storeOfflineTrack(track,blob);button.textContent="✓ Guardada";alert(`“${track.title}” se guardó en la biblioteca offline de CONASOUNDPLAY.`)}catch(e){alert("La fuente bloqueó la descarga o no permite guardar ese audio. Probá otra pista.");button.textContent=old}finally{button.disabled=false}}
function openExternal(url){if(!url)return;const w=window.open(url,"_blank","noopener,noreferrer");if(!w)window.location.href=url;}

document.querySelectorAll("[data-query]").forEach(b=>b.onclick=()=>{$("searchInput").value=b.dataset.query;renderTracks(b.dataset.query);$("tracksSection").scrollIntoView({behavior:"smooth"})});
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>{document.querySelectorAll("[data-view]").forEach(x=>x.classList.remove("active"));b.classList.add("active");const view=b.dataset.view;if(view==="search")$("searchInput").focus();else if(view==="favorites"){const ids=getFavorites();renderTracks("");document.querySelectorAll(".track").forEach(row=>{const title=row.querySelector("strong")?.textContent;row.style.display=ids.some(id=>tracks.find(t=>t.id===id)?.title===title)?"":"none"});$("tracksSection").scrollIntoView({behavior:"smooth"})}else $("tracksSection").scrollIntoView({behavior:"smooth"})});

const dialog=$("authDialog");
function openAuth(){ $("authMessage").textContent="";dialog.showModal()}
$("accountButton").onclick=openAuth;$("topAccount").onclick=openAuth;$("closeAuth").onclick=()=>dialog.close();
$("switchAuth").onclick=()=>{isRegister=!isRegister;$("authTitle").textContent=isRegister?"Crear tu cuenta":"Entrá a CONASOUNDPLAY";$("authDescription").textContent=isRegister?"Registrate para preparar tu perfil.":"Guardá tus favoritos y tu perfil.";$("authSubmit").textContent=isRegister?"Crear cuenta":"Iniciar sesión";$("switchAuth").textContent=isRegister?"Ya tengo cuenta":"¿No tenés cuenta? Registrate";$("emailLabel").style.display=isRegister?"block":"block";$("password").autocomplete=isRegister?"new-password":"current-password"};
$("authForm").addEventListener("submit",async e=>{e.preventDefault();const payload={username:$("username").value.trim(),email:$("email").value.trim(),password:$("password").value};if(!API_BASE){$("authMessage").textContent="El servidor todavía no está conectado. No se enviaron ni guardaron tus datos.";return}try{const r=await fetch(`${API_BASE}/api/auth/${isRegister?"register":"login"}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const data=await r.json();if(!r.ok)throw new Error(data.error||"No se pudo iniciar sesión");sessionUser=data.user;localStorage.setItem("cona_token",data.token);updateProfile(data.user);dialog.close()}catch(err){$("authMessage").textContent=err.message}});
function updateProfile(user){$("miniName").textContent=user.username;$("miniStatus").textContent="Sesión iniciada";$("miniAvatar").textContent=user.username[0].toUpperCase();$("topAccount").textContent=user.username[0].toUpperCase();$("accountButton").textContent="Mi perfil"}
$("chatForm").addEventListener("submit",async e=>{e.preventDefault();const input=$("chatInput"),q=input.value.trim();if(!q)return;appendChat("Vos",q,"user-message");input.value="";if(!API_BASE){appendChat("CONA IA","Todavía no tengo conexión con el servidor. Cuando configuremos Cloudflare Workers, conectaremos una IA real.","assistant-message");return}try{const token=localStorage.getItem("cona_token");const r=await fetch(`${API_BASE}/api/ai/chat`,{method:"POST",headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify({message:q})});const data=await r.json();if(!r.ok)throw new Error(data.error||"Error de conexión");appendChat("CONA IA",data.reply,"assistant-message")}catch(err){appendChat("CONA IA",err.message,"assistant-message")}});
function appendChat(who,msg,cls){const p=document.createElement("p");p.className=cls;p.textContent=who+": "+msg;$("chatLog").append(p);$("chatLog").scrollTop=$("chatLog").scrollHeight}
renderTracks();

// Pantalla de entrada animada: luego revela la app principal.
window.addEventListener("load",()=>{
  const splash=document.getElementById("splash");
  window.setTimeout(()=>{splash?.classList.add("hidden");window.setTimeout(()=>splash?.remove(),800)},2300);
});
