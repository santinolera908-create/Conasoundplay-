# CONASOUNDPLAY — Proyecto Android APK

Este proyecto empaqueta la interfaz web actual dentro de una app Android mediante WebView.

## Qué incluye
- App Android `com.conasoundplay.app`.
- Interfaz web guardada dentro de `app/src/main/assets/www/`.
- Permiso de Internet y almacenamiento local del WebView.
- Buscador multi-fuente: Apple/iTunes, Internet Archive y accesos de búsqueda a YouTube, SoundCloud y Spotify.
- Reproductor para vistas previas oficiales y archivos de audio con acceso directo permitido.
- Descargas offline cuando el proveedor permite descargar el archivo y la conexión lo permite.
- Workflow de GitHub Actions para compilar un APK de prueba sin computadora local.

## Cómo obtener el APK desde el celular (GitHub Actions)
1. Descargá y descomprimí este ZIP.
2. Creá un repositorio nuevo en GitHub desde el navegador del teléfono.
3. Subí todos los archivos y carpetas del proyecto a la raíz del repositorio. Asegurate de incluir `.github/workflows/build-apk.yml`.
4. En GitHub, abrí la pestaña **Actions** y habilitá los workflows si lo pide.
5. Elegí **Build CONASOUNDPLAY APK** y tocá **Run workflow** (o hacé un commit para dispararlo).
6. Cuando termine en verde, abrí esa ejecución, bajá el artifact **CONASOUNDPLAY-debug-apk.zip** y extraelo.
7. Dentro estará `app-debug.apk`. Abrilo en el teléfono y autorizá instalar apps desde esa fuente si Android lo pide.

## Para compilar con Android Studio
1. Abrí la carpeta del proyecto en Android Studio.
2. Usá JDK 17 y deja que Gradle sincronice.
3. Ejecutá `assembleDebug`, o `Build > Build APK(s)`.
4. APK generado: `app/build/outputs/apk/debug/app-debug.apk`.

## Importante
- Este APK es una compilación de prueba (debug), no una publicación firmada para Play Store.
- La app puede reproducir pistas de demostración si hay conexión. Los botones “↓ Celular” y “＋ En la app” intentan descargar fuentes que permitan guardar el audio; la disponibilidad depende de permisos, CORS, conexión y almacenamiento. Las pistas guardadas en la base local del WebView se pueden reproducir sin conexión dentro de la app en ese dispositivo.
- El buscador consulta Apple/iTunes e Internet Archive; además ofrece enlaces a búsquedas en YouTube, SoundCloud y Spotify. No significa que todas las canciones de esas plataformas puedan reproducirse dentro de la app.
- Las vistas previas de Apple/iTunes pueden ser fragmentos. Internet Archive contiene grabaciones variadas y la disponibilidad/licencia cambia según el elemento; revisá la fuente antes de guardar o reutilizar.
- No se extrae audio de YouTube ni se eluden controles de acceso. Las descargas solo funcionan cuando el proveedor ofrece un archivo accesible y permite guardarlo.
- La autenticación y CONA IA siguen desactivadas hasta configurar el backend seguro y el proveedor de IA.
- Descargas externas y offline dependen de que el proveedor permita acceso/descarga. Las descargas guardadas en IndexedDB se almacenan en los datos del WebView y pueden borrarse si se eliminan los datos de la app.
- No pongas contraseñas, tokens ni claves privadas en el código frontend.
- No se incluye Gradle Wrapper binario; GitHub Actions usa Gradle instalado en el runner.


## Importante al subirlo desde el teléfono
No subas este ZIP como único archivo al repositorio. Extraelo primero y subí el contenido de la carpeta `CONASOUNDPLAY_ANDROID` (incluida la carpeta `.github/workflows`) a la raíz del repositorio.
